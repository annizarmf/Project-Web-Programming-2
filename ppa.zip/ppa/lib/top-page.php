<?php include "koneksi.php";?>

<head><title>Sistem Informasi UPTD KTPA | SIMPUG ONLINE</title></head>
<link rel="stylesheet" type="text/css" href="../css/style1.css" />
<div class="menu">
<ul>
        <li><a href="../admin/login.php">Home</a></li>
        <li><a href="#">Kelola Data </a>
    <ul>
            <li><a href="../admin/lihat_kasus.php">Kelola Data Kasus</a></li>
            <li><a href="../admin/lihat_korban.php">Kelola Data Korban</a></li>
            <li><a href="../admin/lihat_pelapor.php">Kelola Data Pelapor</a></li>
            <li><a href="../admin/lihat_terlapor.php">Kelola Data Terlapor</a></li>
    </ul>
    <li><a href="../home/home.php">ARSIP</a></li>
    </li>

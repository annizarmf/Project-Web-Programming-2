<?php

class FormKasus {
    private $koneksi;

    public function __construct($koneksi) {
        $this->koneksi = $koneksi;
    }

    public function saveData($JenisKasus, $SubKasus, $Keterangan, $Kronologis, $KondisiKorban, $Upaya, $KebutuhanKorban) {
        $query = "INSERT INTO formkasus SET
                    JenisKasus = '$JenisKasus',
                    SubKasus = '$SubKasus',
                    Keterangan = '$Keterangan',
                    Kronologis = '$Kronologis',
                    KondisiKorban = '$KondisiKorban',
                    Upaya = '$Upaya',
                    KebutuhanKorban = '$KebutuhanKorban'";
        
        mysqli_query($this->koneksi, $query);
        echo "DATA TELAH TERSIMPAN";
    }
}

include "koneksi.php"; // Assuming this file contains your database connection

if(isset($_POST['proses'])){
    $form = new FormKasus($koneksi);
    $form->saveData(
        $_POST['JenisKasus'],
        $_POST['SubKasus'],
        $_POST['Keterangan'],
        $_POST['Kronologis'],
        $_POST['KondisiKorban'],
        $_POST['Upaya'],
        $_POST['KebutuhanKorban']
    );
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .styled-table {
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.9em;
            font-family: sans-serif;
            min-width: 400px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
        }
        .styled-table thead tr {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
        }
        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
        }
        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }
        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }
        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
        .styled-table tbody tr.active-row {
            font-weight: bold;
            color: #009879;
        }
    </style>
</head>
<body>
    <div style="margin: 0 auto; width:40%; background: white;">
        <h3 align="center">DATA KASUS</h3> 
        <form method="post">
            <table class="styled-table">
                <tr>
                    <td width="130">Jenis Kasus</td>
                    <td>:</td>
                    <td><select name="JenisKasus">
                        <option value="">-- Pilih -- </option>
                        <option value="KDRT"> KDRT (Kekerasan Dalam Rumah Tangga)</option>
                        <option value="KBGO"> KBGO (Kekerasan Berbasis Gender Online)</option>
                        <option value="KTP">KTP (Kekerasan Terhadap Perempuan)</option>
                        <option value="TPPO">KDP (Kekerasan Dalam Pacaran)</option>
                        <option value="TPPO">TPPO (Tindak Pidana Perdagangan Orang)</option>
                        <option value="ODGJ">ODGJ (Orang Dengan Gangguan Jiwa)</option>
                        <option value="KTA/ABK">KTA/ABK (Anak Berkebutuhan Khusus)</option>
                    </select></td>
                </tr>
                <tr>
                    <td>Sub Kasus </td>
                    <td>:</td>
                    <td><select name="SubKasus">
                        <option value="">-- Pilih -- </option>
                        <option value="Bullying">Bullying</option>
                        <option value="Pelecehan">Pelecehan </option>
                        <option value="Pencabulan"> Persetubuhan</option>
                        <option value="penelantaran"> Penelantaran </option>
                        <option value="Pencabulan"> Pencabulan</option>
                        <option value="Pemerkosaan">Pemerkosaan</option>
                        <option value="Kekerasan Fisik">Kekerasan Fisik </option>
                        <option value="Kekerasan Psikis">Kekerasan Psikis</option>
                    </select></td>
                </tr>
                <tr>
                    <td valign="top">Keterangan</td>
                    <td>:</td>
                    <td><textarea name="Keterangan" cols="30"></textarea></td>
                </tr>
                <tr>
                    <td valign="top">Kronologis</td>
                    <td>:</td>
                    <td><textarea name="Kronologis" cols="30"></textarea></td>
                </tr>
                <tr>
                    <td valign="top">Kondisi dan Kebutuhan</td>
                    <td>:</td>
                    <td><textarea name="KondisiKorban" cols="30"></textarea></td>
                </tr>
                <tr>
                    <td valign="top">Upaya yang Telah Dilakukan</td>
                    <td>:</td>
                    <td><textarea name="Upaya" cols="30"></textarea></td>
                </tr>
                <tr>
                    <td>Kebutuhan Korban </td>
                    <td>:</td>
                    <td><select name="KebutuhanKorban">
                        <option value="">-- Pilih -- </option>
                        <option value="Pendampingan_Hukum">Pendampingan Hukum</option>
                        <option value="Pendampingan_Psikolog">Pendampingan Psikolog</option>
                        <option value="Mediasi">Mediasi</option>
                        <option value="Rumah_Aman">Rumah Aman</option>
                    </select></td>
                </tr>
                <tr>
                    <td><input type="submit" name="proses" value="Simpan">
                    <input type="reset" value="Reset"></td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>

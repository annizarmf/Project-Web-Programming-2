<?php

include "koneksi.php";

class FormData {
    private $JenisKasus;
    private $SubKasus;
    private $Keterangan;
    private $Kronologis;
    private $AlamatPel;
    private $KondisiKorban;
    private $Upaya;
    private $KebutuhanKroban;

    public function __construct($data) {
        $this->JenisKasus = $data['JenisKasus'];
        $this->SubKasus = $data['SubKasus'];
        $this->Keterangan = $data['Keterangan'];
        $this->Kronologis = $data['JenisKelaminPel'];
        $this->AlamatPel = $data['Kronologis'];
        $this->KondisiKorban = $data['KondisiKorban'];
        $this->Upaya = $data['Upaya'];
        $this->KebutuhanKroban = $data['KebutuhanKorban'];
    }

    public function getJenisKasus() {
        return $this->JenisKasus;
    }

    // Add getters for other properties as needed
}

class DataKasusHandler {
    private $koneksi;

    public function __construct($koneksi) {
        $this->koneksi = $koneksi;
    }

    public function insertData(FormData $formData) {
        $JenisKasus = $formData->getJenisKasus();
        $SubKasus = $formData->getSubKasus();
        $Keterangan = $formData->getKeterangan();
        $Kronologis = $formData->getKronologis();
        $AlamatPel = $formData->getAlamatPel();
        $KondisiKorban = $formData->getKondisiKorban();
        $Upaya = $formData->getUpaya();
        $KebutuhanKroban = $formData->getKebutuhanKroban();

        $cek = mysqli_query($this->koneksi, "SELECT * from data_kasus where NIKPel ='$SubKasus'");
        $jumlah = mysqli_num_rows($cek);

        if ($jumlah == 1) {
            $query = "INSERT into datakasus set 
                JenisKasus ='$JenisKasus',
                SubKasus ='$SubKasus',
                Keterangan ='$Keterangan',
                Kronologis ='$Kronologis',
                KondisiKorban ='$KondisiKorban',
                Upaya ='$Upaya',
                KebutuhanKorban ='$KebutuhanKroban'";
            
            $simpan = mysqli_query($this->koneksi, $query);

            if ($simpan) {
                echo "
                    <script>
                        alert('Data berhasil ditambahkan');
                        window.location = 'data_kasus.php';
                    </script>
                ";
            }
        }
    }
}

$data = [
    'JenisKasus' => $_POST['JenisKasus'],
    'SubKasus' => $_POST['SubKasus'],
    'Keterangan' => $_POST['Keterangan'],
    'JenisKelaminPel' => $_POST['JenisKelaminPel'],
    'Kronologis' => $_POST['Kronologis'],
    'KondisiKorban' => $_POST['KondisiKorban'],
    'Upaya' => $_POST['Upaya'],
    'KebutuhanKorban' => $_POST['KebutuhanKorban']
];

$formData = new FormData($data);
$dataKasusHandler = new DataKasusHandler($koneksi);
$dataKasusHandler->insertData($formData);

?>

<?php

class PelaporForm {
    private $NamaPel;
    private $NIKPel;
    private $TglLahirPel;
    private $JenisKelaminPel;
    private $AlamatPel;
    private $RTRWPel;
    private $KelurahanPel;
    private $KecamatanPel;
    private $NoHpPel; // Added NoHpPel field
    private $PekerjaanPel;
    private $AgamaPel;
    private $HubDenganKorban;

    public function __construct($data) {
        $this->NamaPel = $data['NamaPel'];
        $this->NIKPel = $data['NIKPel'];
        $this->TglLahirPel = $data['TglLahirPel'];
        $this->JenisKelaminPel = $data['JenisKelaminPel'];
        $this->AlamatPel = $data['AlamatPel'];
        $this->RTRWPel = $data['RTRWPel'];
        $this->KelurahanPel = $data['KelurahanPel'];
        $this->KecamatanPel = $data['KecamatanPel'];
        $this->NoHpPel = $data['NoHpPel'];
        $this->PekerjaanPel = $data['PekerjaanPel'];
        $this->AgamaPel = $data['AgamaPel'];
        $this->HubDenganKorban = $data['HubDenganKorban'];
    }

    public function renderForm() {
        return "
        <html>
        <head>
            <title>Form Data Pelapor</title>
            <style>
                .styled-table {
                    border-collapse: collapse;
                    margin: 25px 0;
                    font-size: 0.9em;
                    font-family: sans-serif;
                    min-width: 400px;
                    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
                }
                .styled-table thead tr {
                    background-color: #009879;
                    color: #ffffff;
                    text-align: left;
                }
                .styled-table th,
                .styled-table td {
                    padding: 12px 15px;
                }
                .styled-table tbody tr {
                    border-bottom: 1px solid #dddddd;
                }
                .styled-table tbody tr:nth-of-type(even) {
                    background-color: #f3f3f3;
                }
                .styled-table tbody tr:last-of-type {
                    border-bottom: 2px solid #009879;
                }
                .styled-table tbody tr.active-row {
                    font-weight: bold;
                    color: #009879;
                }
            </style>
        </head>
        <body>
            <h1>Form Data Pelapor</h1>
            <form action='simpan_pelapor.php' method='post'>
                <table class='styled-table'>
                    <tr>
                        <td>Nama</td>
                        <td>:</td>
                        <td><input type='text' name='NamaPel' size='30' value='{$this->NamaPel}'></td>
                    </tr>
                    <tr>
                        <td>NIK</td>
                        <td>:</td>
                        <td><input type='text' name='NIKPel' size='16' value='{$this->NIKPel}'></td>
                    </tr>
                    <tr>
                        <td>Tanggal Lahir</td>
                        <td>:</td>
                        <td><input type='date' name='TglLahirPel' value='{$this->TglLahirPel}'></td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td>:</td>
                        <td><input type='text' name='JenisKelaminPel' size='10' value='{$this->JenisKelaminPel}'></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td>:</td>
                        <td><input type='text' name='AlamatPel' size='100' value='{$this->AlamatPel}'></td>
                    </tr>
                    <tr>
                        <td>RT/RW</td>
                        <td>:</td>
                        <td><input type='text' name='RTRWPel' size='10' value='{$this->RTRWPel}'></td>
                    </tr>
                    <tr>
                        <td>Kelurahan</td>
                        <td>:</td>
                        <td><input type='text' name='KelurahanPel' size='30' value='{$this->KelurahanPel}'></td>
                    </tr>
                    <tr>
                        <td>Kecamatan</td>
                        <td>:</td>
                        <td><input type='text' name='KecamatanPel' size='30' value='{$this->KecamatanPel}'></td>
                    </tr>
                    <tr>
                        <td>NO HP</td>
                        <td>:</td>
                        <td><input type='text' name='NoHpPel' size='15' value='{$this->NoHpPel}'></td>
                    </tr>
                    <tr>
                        <td>Pekerjaan</td>
                        <td>:</td>
                        <td><input type='text' name='PekerjaanPel' size='30' value='{$this->PekerjaanPel}'></td>
                    </tr>
                    <tr>
                        <td>Agama</td>
                        <td>:</td>
                        <td><input type='text' name='AgamaPel' size='10' value='{$this->AgamaPel}'></td>
                    </tr>
                    <tr>
                        <td>Hubungan Dengan Korban</td>
                        <td>:</td>
                        <td><input type='text' name='HubDenganKorban' size='30' value='{$this->HubDenganKorban}'></td>
                    </tr>
                </table>
                <input type='submit' name='proses' value='Simpan'>
                <a href='lihat_pelapor.php'><input type='button' value='Lihat'></a>
                <input type='reset' value='Reset'>
            </form>
        </body>
        </html>";
    }
}

// Example usage:
$data = $_GET; // Assuming data comes from GET request, adjust as needed
$form = new PelaporForm($data);
echo $form->renderForm();

?>

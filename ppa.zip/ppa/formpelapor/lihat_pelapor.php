<?php

class HTMLRenderer {
    public static function renderHead() {
        return "
        <head>
            <style>
                .styled-table {
                    border-collapse: collapse;
                    margin: 25px 0;
                    font-size: 0.9em;
                    font-family: sans-serif;
                    min-width: 400px;
                    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
                }
                .styled-table thead tr {
                    background-color: #009879;
                    color: #ffffff;
                    text-align: left;
                }
                .styled-table th,
                .styled-table td {
                    padding: 12px 15px;
                }
                .styled-table tbody tr {
                    border-bottom: 1px solid #dddddd;
                }
                .styled-table tbody tr:nth-of-type(even) {
                    background-color: #f3f3f3;
                }
                .styled-table tbody tr:last-of-type {
                    border-bottom: 2px solid #009879;
                }
                .styled-table tbody tr.active-row {
                    font-weight: bold;
                    color: #009879;
                }
            </style>
        </head>";
    }
}

class DataFetcher {
    private $koneksi;

    public function __construct($koneksi) {
        $this->koneksi = $koneksi;
    }
    public function fetchPelaporData() {
        $pelapor = mysqli_query($this->koneksi, "SELECT * FROM datapelapor");
        if (!$pelapor) {
            die("Error: " . mysqli_error($this->koneksi));
        }
        $data = [];
        while ($row = mysqli_fetch_assoc($pelapor)) {
            $data[] = $row;
        }
        return $data;
    }
    
}

class HTMLTableRenderer {
    public static function renderPelaporTable($data) {
        $html = "<a href='pelapor.php'>Kembali</a><br><h3>Data Pelapor</h3>";
        $html .= "<table border='1' class='styled-table'>
                    <tr>
                        <td>No</td>
                        <td>Nama</td>
                        <td>NIK</td>
                        <td>Tanggal Lahir</td>
                        <td>Jenis Kelamin</td>
                        <td>Alamat</td>
                        <td>RT/RW</td>
                        <td>Kelurahan</td>
                        <td>Kecamatan</td>
                        <td>Pekerjaan</td>
                        <td>Agama</td>
                        <td>Hubungan Dengan Korban</td>
                    </tr>";

        foreach ($data as $key => $row) {
            $class = $key % 2 == 0 ? 'genap' : 'ganjil';
            $html .= "<tr class='$class'>
                        <td>".($key + 1)."</td>
                        <td>{$row['NamaPel']}</td>
                        <td>{$row['NIKPel']}</td>
                        <td>{$row['TglLahirPel']}</td>
                        <td>{$row['JenisKelaminPel']}</td>
                        <td>{$row['AlamatPel']}</td>
                        <td>{$row['RTRWPel']}</td>
                        <td>{$row['KelurahanPel']}</td>
                        <td>{$row['KecamatanPel']}</td>
                        <td>{$row['PekerjaanPel']}</td>
                        <td>{$row['AgamaPel']}</td>
                        <td>{$row['HubDenganKorban']}</td>
                    </tr>";
        }

        $html .= "</table>";
        return $html;
    }
}

// Example usage:
include "koneksi.php"; // Assuming the file contains database connection information

$html = HTMLRenderer::renderHead();
$dataFetcher = new DataFetcher($koneksi);
$pelaporData = $dataFetcher->fetchPelaporData();
$html .= HTMLTableRenderer::renderPelaporTable($pelaporData);
echo $html;

?>

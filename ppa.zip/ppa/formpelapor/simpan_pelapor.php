<?php

class DataProcessor {
    private $koneksi;

    public function __construct($koneksi) {
        $this->koneksi = $koneksi;
    }

    public function processData($data) {
        $NamaPel = $data['NamaPel'];
        $NIKPel = $data['NIKPel'];
        $TglLahirPel = $data['TglLahirPel'];
        $JenisKelaminPel = $data['JenisKelaminPel'];
        $AlamatPel = $data['AlamatPel'];
        $RTRWPel = $data['RTRWPel'];
        $KeluharanPel = $data['KelurahanPel']; // Corrected variable name
        $KecamatanPel = $data['KecamatanPel'];
        $PekerjaanPel = $data['PekerjaanPel'];
        $AgamaPel = $data['AgamaPel'];
        $HubDenganKorban = $data['HubDenganKorban'];

        // Perform data validation and database operation
        $cek = mysqli_query($this->koneksi, "SELECT * from datapelapor where NIKPel ='$NIKPel'");
        $jumlah = mysqli_num_rows($cek);

        if ($jumlah == 1) {
            return "Data sudah ada";
        } else {
            $simpan = mysqli_query($this->koneksi, "INSERT into datapelapor set 
            NamaPel ='$NamaPel',
            NIKPel ='$NIKPel',
            TglLahirPel ='$TglLahirPel',
            JenisKelaminPel ='$JenisKelaminPel',
            AlamatPel ='$AlamatPel',
            RTRWPel ='$RTRWPel',
            KelurahanPel ='$KeluharanPel',
            KecamatanPel ='$KecamatanPel',
            PekerjaanPel ='$PekerjaanPel',
            HubDenganKorban ='$HubDenganKorban'");

            if ($simpan) {
                return "Data berhasil ditambahkan";
            } else {
                return "Gagal menambahkan data";
            }
        }
    }
}

// Example usage:
include "koneksi.php"; // Assuming the file contains database connection information
$dataProcessor = new DataProcessor($koneksi); // Assuming $koneksi is the database connection
$resultMessage = $dataProcessor->processData($_POST);
echo "<script>alert('$resultMessage'); window.location = 'pelapor.php';</script>";

?>

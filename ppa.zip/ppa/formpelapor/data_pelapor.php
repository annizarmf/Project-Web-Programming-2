<?php

class HTMLRenderer {
    public static function renderHead() {
        return "
        <!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Data Pelapor</title>
            <style>
                .styled-table {
                    border-collapse: collapse;
                    margin: 25px 0;
                    font-size: 0.9em;
                    font-family: sans-serif;
                    min-width: 400px;
                    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
                }
                .styled-table thead tr {
                    background-color: #009879;
                    color: #ffffff;
                    text-align: left;
                }
                .styled-table th,
                .styled-table td {
                    padding: 12px 15px;
                }
                .styled-table tbody tr {
                    border-bottom: 1px solid #dddddd;
                }
                .styled-table tbody tr:nth-of-type(even) {
                    background-color: #f3f3f3;
                }
                .styled-table tbody tr:last-of-type {
                    border-bottom: 2px solid #009879;
                }
                .styled-table tbody tr.active-row {
                    font-weight: bold;
                    color: #009879;
                }
            </style>
        </head>";
    }

    public static function renderForm() {
        return "
        <body>
            <div style='margin: 0 auto; width:40%; background: white;'>
                <h3 align='center'>DATA PELAPOR</h3>
                <form method='post'>
                    <table class='styled-table'>
                        <tr>
                            <td>Nama</td>
                            <td>:</td>
                            <td><input type='text' name='NamaPel' size='30'></td>
                        </tr>
                        <tr>
                            <td>NIK</td>
                            <td>:</td>
                            <td><input type='text' name='NIKPel' size='16'></td>
                        </tr>
                        <tr>
                            <td>Tanggal Lahir</td>
                            <td>:</td>
                            <td><input type='date' name='TglLahirPel'></td>
                        </tr>
                        <tr>
                            <td>Jenis Kelamin</td>
                            <td>:</td>
                            <td><input type='text' name='JenisKelaminPel' size='10'></td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td><textarea name='AlamatPel' rows='4' cols='50'></textarea></td>
                        </tr>
                        <tr>
                            <td>RT/RW</td>
                            <td>:</td>
                            <td><input type='text' name='RTRWPel' size='10'></td>
                        </tr>
                        <tr>
                            <td>Kelurahan</td>
                            <td>:</td>
                            <td><input type='text' name='KelurahanPel' size='30'></td>
                        </tr>
                        <tr>
                            <td>Kecamatan</td>
                            <td>:</td>
                            <td><input type='text' name='KecamatanPel' size='30'></td>
                        </tr>
                        <tr>
                            <td>NO HP</td>
                            <td>:</td>
                            <td><input type='text' name='NoHpPel' size='15'></td>
                        </tr>
                        <tr>
                            <td>Pekerjaan</td>
                            <td>:</td>
                            <td><input type='text' name='PekerjaanPel' size='30'></td>
                        </tr>
                        <tr>
                            <td>Agama</td>
                            <td>:</td>
                            <td><input type='text' name='AgamaPel' size='10'></td>
                        </tr>
                        <tr>
                            <td>Hubungan Dengan Korban</td>
                            <td>:</td>
                            <td><input type='text' name='HubDenganKorban' size='30'></td>
                        </tr>
                    </table>
                    <input type='submit' name='proses' value='Simpan'>
                    <input type='reset' value='Reset'>
                </form>
            </div>";

    }
}

class DataProcessor {
    private $koneksi;

    public function __construct($koneksi) {
        $this->koneksi = $koneksi;
    }

    public function processData() {
        if(isset($_POST['proses'])) {
            mysqli_query($this->koneksi, "INSERT INTO datapelapor SET
                NamaPel = '$_POST[NamaPel]',
                NIKPel = '$_POST[NIKPel]',
                TglLahirPel = '$_POST[TglLahirPel]',
                JenisKelaminPel = '$_POST[JenisKelaminPel]',
                AlamatPel = '$_POST[AlamatPel]',
                RTRWPel = '$_POST[RTRWPel]',
                KelurahanPel = '$_POST[KelurahanPel]',
                KecamatanPel = '$_POST[KecamatanPel]',
                NoHpPel = '$_POST[NoHpPel]',
                PekerjaanPel = '$_POST[PekerjaanPel]',
                AgamaPel = '$_POST[AgamaPel]',
                HubDenganKorban = '$_POST[HubDenganKorban]'
            ");
            return "DATA TELAH TERSIMPAN";
        }
        return "";
    }
}

// Example usage:
include "koneksi.php"; // Assuming the file contains database connection information

$html = HTMLRenderer::renderHead();
$html .= HTMLRenderer::renderForm();
$dataProcessor = new DataProcessor($koneksi);
$message = $dataProcessor->processData();
$html .= $message;
$html .= "</body></html>";

echo $html;

?>

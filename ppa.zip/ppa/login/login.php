<?php
// Define User class
class User {
    private $username;
    private $password;

    public function __construct($username, $password) {
        $this->username = $username;
        $this->password = $password;
    }

    public function getUsername() {
        return $this->username;
    }

    public function getPassword() {
        return $this->password;
    }
}

// Define LoginForm class
class LoginForm {
    private $username;
    private $password;
    private $users;

    public function __construct($username, $password, $users) {
        $this->username = $username;
        $this->password = $password;
        $this->users = $users;
    }

    public function authenticate() {
        foreach ($this->users as $user) {
            if ($user->getUsername() === $this->username && $user->getPassword() === $this->password) {
                return true;
            }
        }
        return false;
    }
}

// Define users
$users = array(
    new User('user1', 'password1'),
    new User('user2', 'password2')
);

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve username and password from the form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Create a LoginForm object
    $loginForm = new LoginForm($username, $password, $users);

    // Authenticate the user
    if ($loginForm->authenticate()) {
        // Redirect to dashboard or another page
        header('Location: dashboard.php');
        exit(); // Stop further execution
    } else {
        // Display error message
        echo "Invalid username or password. Please try again.";
    }
}
?>

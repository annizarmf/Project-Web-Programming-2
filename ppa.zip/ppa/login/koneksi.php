<?php

$host = "localhost";
$user = "sihy5111_ktpa";
$pass = "(X+SemyU#Mfm";
$db = "sihy5111_laporan_kasus";

$koneksi = mysqli_connect($host, $user, $pass, $db);

?>

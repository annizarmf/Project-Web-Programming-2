<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Homepage</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .header {
            background-color: #009879;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .container {
            margin: 20px auto;
            max-width: 800px;
            text-align: center;
        }
        .card {
            background-color: white;
            padding: 20px;
            margin: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .card h3 {
            margin: 0;
            color: #009879;
        }
        .card p {
            margin: 10px 0;
            color: #333;
        }
        .card a, .dropdown button {
            display: inline-block;
            margin-top: 10px;
            padding: 10px 15px;
            background-color: #009879;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
        }
        .card a:hover, .dropdown button:hover {
            background-color: #007b5e;
        }
        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            min-width: 160px;
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Selamat Datang, Admin</h1>
        <a href="logout.php" style="color: white;">Logout</a>
    </div>
    <div class="container">
        <div class="card">
            <h3>Kelola Admin</h3>
            <p>Tambahkan, Ubah dan Hapus Akun Admin.</p>
            <a href="manage_users.php">Pergi ke Pengelolaan Akun</a>
        </div>
        <div class="card">
            <h3>Lihat Laporan</h3>
            <p>Lihat dan Analisa Laporan KTPA Kab. Bekasi.</p>
            <div class="dropdown">
                <button>Pergi ke Laporan.</button>
                <div class="dropdown-content">
                    <a href="lihat_korban.php">Korban</a>
                    <a href="lihat_pelapor.php">Pelapor</a>
                    <a href="lihat_terlapor.php">Terlapor</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php include "../lib/koneksi.php";?>
<head>
 	<style>
    .styled-table {
    border-collapse: collapse;
    margin: 25px 0;
    font-size: 0.9em;
    font-family: sans-serif;
    min-width: 400px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }
    .styled-table thead tr {
    background-color: #009879;
    color: #ffffff;
    text-align: left;
    }
    .styled-table th,
    .styled-table td {
    padding: 12px 15px;
    }
    .styled-table tbody tr {
    border-bottom: 1px solid #dddddd;
    }
    .styled-table tbody tr:nth-of-type(even) {
    background-color: #f3f3f3;
    }
    .styled-table tbody tr:last-of-type {
    border-bottom: 2px solid #009879;
    }
    .styled-table tbody tr.active-row {
    font-weight: bold;
    color: #009879;
    }
			#kembali {
            background-color: #009879;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 10px 0;
            cursor: pointer;
            border-radius: 5px;
        }
        #kembali:hover {
            background-color: #007b5e;
		}
 </style>
</head>

<?php
 $pelapor = mysqli_query($koneksi, "SELECT * from datapelapor");
 $jumlah_baris = mysqli_num_rows($pelapor);
 
 //echo $jm_baris."<br>"; 
 echo "<a href=admin_homepage.php id=kembali>Kembali</a>";
 echo "<br><h3>Data Pelapor</h3>";
 echo "<table border=1 class=styled-table>
		<tr>
		<td>No</td>
		 <td>Nama</td>
		 <td>NIK</td>
		 <td>Tanggal Lahir</td>
		 <td>Jenis Kelamin</td>
		 <td>Alamat</td>
		 <td>RT/RW</td>
		 <td>Kelurahan</td>
		 <td>Kecamatan</td>
		 <td>Pekerjaan</td>
		 <td>Agama</td>
		 <td>Hubungan Dengan Korban</td>
		</tr>" ;
 
 	for($k=1; $k<=$jumlah_baris; $k++)
 	{
	 $data = mysqli_fetch_assoc($pelapor);
	 if($k % 2 == 1)
	 {
	 echo "<tr class=ganjil>
			<td>$k</td>
			<td>".$data['NamaPel']."</td>
		    <td>".$data['NIKPel']."</td>
			<td>".$data['TglLahirPel']."</td>
			<td>".$data['JenisKelaminPel']."</td>
			<td>".$data['AlamatPel']."</td>
			<td>".$data['RTRWPel']."</td>
			<td>".$data['KelurahanPel']."</td>
			<td>".$data['KecamatanPel']."</td>
			<td>".$data['PekerjaanPel']."</td>
			<td>".$data['AgamaPel']."</td>
			<td>".$data['HubDenganKorban']."</td>
		   </tr>";
	   }
	   else
	   {
		    echo "<tr class=genap>
			<td>$k</td>
			<td>".$data['NamaPel']."</td>
		    <td>".$data['NIKPel']."</td>
			<td>".$data['TglLahirPel']."</td>
			<td>".$data['JenisKelaminPel']."</td>
			<td>".$data['AlamatPel']."</td>
			<td>".$data['RTRWPel']."</td>
			<td>".$data['KelurahanPel']."</td>
			<td>".$data['KecamatanPel']."</td>
			<td>".$data['PekerjaanPel']."</td>
			<td>".$data['AgamaPel']."</td>
			<td>".$data['HubDenganKorban']."</td>
		   </tr>";
	   }
 	}	
	 echo "</table>";

?>

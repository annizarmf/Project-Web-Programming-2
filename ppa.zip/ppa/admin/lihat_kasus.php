<?php include "../lib/top-page.php"; ?>
<?php include "../lib/koneksi.php";?>
<head>
 	<style>
    .styled-table {
    border-collapse: collapse;
    margin: 25px 0;
    font-size: 0.9em;
    font-family: sans-serif;
    min-width: 400px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }
    .styled-table thead tr {
    background-color: #009879;
    color: #ffffff;
    text-align: left;
    }
    .styled-table th,
    .styled-table td {
    padding: 12px 15px;
    }
    .styled-table tbody tr {
    border-bottom: 1px solid #dddddd;
    }
    .styled-table tbody tr:nth-of-type(even) {
    background-color: #f3f3f3;
    }
    .styled-table tbody tr:last-of-type {
    border-bottom: 2px solid #009879;
    }
    .styled-table tbody tr.active-row {
    font-weight: bold;
    color: #009879;
    }
 </style>
</head>

<?php
 $data_kasus = mysqli_query($koneksi, "SELECT * from formkasus");
 $jumlah_baris = mysqli_num_rows($data_kasus);

 echo "<a href=data_kasus.php>Kembali</a>";
 echo "<br><h3>Data kasus</h3>";
 echo "<table border=1 class=styled-table>
 <tr>
 <td>No</td>
  <td>Jenis Kasus</td>
  <td>Sub Kasus</td>
  <td>Keterangan</td>
  <td>Kronologis</td>
  <td>Kondisi Korban</td>
  <td>Upaya</td>
  <td>Kebutuhan Korban</td>
 </tr>" ;


 	for($k=1; $k<=$jumlah_baris; $k++)
 	{
	 $data = mysqli_fetch_assoc($data_kasus);
	 if($k % 2 == 1)
	 {
	 echo "<tr class=ganjil>
			<td>$k</td>
			<td>".$data['JenisKasus']."</td>
		    <td>".$data['SubKasus']."</td>
			<td>".$data['Keterangan']."</td>
			<td>".$data['Kronologis']."</td>
			<td>".$data['KondisiKorban']."</td>
			<td>".$data['Upaya']."</td>
			<td>".$data['KebutuhanKorban']."</td>
		   </tr>";
	   }
	   else
	   {
		    echo "<tr class=genap>
			<td>$k</td>
			<td>".$data['JenisKasus']."</td>
		    <td>".$data['SubKasus']."</td>
			<td>".$data['Keterangan']."</td>
			<td>".$data['Kronologis']."</td>
			<td>".$data['KondisiKorban']."</td>
			<td>".$data['Upaya']."</td>
			<td>".$data['KebutuhanKorban']."</td>
		   </tr>";
	   }
 	}	
	 echo "</table>";

?>

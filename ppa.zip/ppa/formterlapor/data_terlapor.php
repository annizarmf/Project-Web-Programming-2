<?php

// FormData class representing the form data
class FormData {
    public $nama;
    public $nik;
    public $tanggal_lahir;
    public $jenis_kelamin;
    public $alamat;
    public $rt_rw;
    public $kelurahan;
    public $kecamatan;
    public $no_hp;
    public $pekerjaan;
    public $agama;
    public $hubungan_dengan_korban;

    // Constructor to initialize form data
    public function __construct($data) {
        $this->nama = $data['NamaTer'];
        $this->nik = $data['NIKTer'];
        $this->tanggal_lahir = $data['TglLahirTer'];
        $this->jenis_kelamin = $data['JenisKelaminTer'];
        $this->alamat = $data['AlamatTer'];
        $this->rt_rw = $data['RTRWTer'];
        $this->kelurahan = $data['KelurahanTer'];
        $this->kecamatan = $data['KecamatanTer'];
        $this->no_hp = $data['NoHpTer'];
        $this->pekerjaan = $data['PekerjaanTer'];
        $this->agama = $data['AgamaTer'];
        $this->hubungan_dengan_korban = $data['HubDenganKorbanTer'];
    }
}

// Database class representing the database interaction
class Database {
    private $connection;

    // Constructor to initialize database connection
    public function __construct($connection) {
        $this->connection = $connection;
    }

    // Method to insert data into the database
    public function insertData($formData) {
        // Connect to the database
        include "koneksi.php";

        // Insert data into the database
        $query = "INSERT INTO dataterlapor (NamaTer, NIKTer, TglLahirTer, JenisKelaminTer, AlamatTer, RTRWTer, KelurahanTer, KecamatanTer, NoHpTer, PekerjaanTer, AgamaTer, HubDenganKorbanTer) 
        VALUES ('$formData->nama', '$formData->nik', '$formData->tanggal_lahir', '$formData->jenis_kelamin', '$formData->alamat', '$formData->rt_rw', '$formData->kelurahan', '$formData->kecamatan', '$formData->no_hp', '$formData->pekerjaan', '$formData->agama', '$formData->hubungan_dengan_korban')";
        if (mysqli_query($this->connection, $query)) {
            echo "DATA TELAH TERSIMPAN";
        } else {
            echo "Error: " . $query . "<br>" . mysqli_error($this->connection);
        }

        // Close the database connection
        mysqli_close($this->connection);
    }
}

// Form class representing the HTML form
class Form {
    // Method to render the HTML form
    public function render() {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Data Terlapor</title>
            <style>
                .styled-table {
                    border-collapse: collapse;
                    margin: 25px 0;
                    font-size: 0.9em;
                    font-family: sans-serif;
                    min-width: 400px;
                    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
                }
                .styled-table thead tr {
                    background-color: #009879;
                    color: #ffffff;
                    text-align: left;
                }
                .styled-table th,
                .styled-table td {
                    padding: 12px 15px;
                }
                .styled-table tbody tr {
                    border-bottom: 1px solid #dddddd;
                }
                .styled-table tbody tr:nth-of-type(even) {
                    background-color: #f3f3f3;
                }
                .styled-table tbody tr:last-of-type {
                    border-bottom: 2px solid #009879;
                }
                .styled-table tbody tr.active-row {
                    font-weight: bold;
                    color: #009879;
                }
            </style>
        </head>
        <body>
        <div style="margin: 0 auto; width:40%; background: white;">
            <h3 align="center">DATA TERLAPOR</h3> 
            <form method="post">
                <table class="styled-table">
                    <tr>
                        <td>Nama</td>
                        <td>:</td>
                        <td><input type="text" name="NamaTer" size="30"></td>
                    </tr>
                    <tr>
                        <td>NIK</td>
                        <td>:</td>
                        <td><input type="text" name="NIKTer" size="16"></td>
                    </tr>
                    <tr>
                        <td>Tanggal Lahir</td>
                        <td>:</td>
                        <td><input type="date" name="TglLahirTer"></td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td>:</td>
                        <td><input type="text" name="JenisKelaminTer" size="10"></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td>:</td>
                        <td><textarea type="text" name="AlamatTer" size="100"></textarea></td>
                    </tr>
                    <tr>
                        <td>RT/RW</td>
                        <td>:</td>
                        <td><input type="text" name="RTRWTer" size="10"></td>
                    </tr>
                    <tr>
                        <td>Kelurahan</td>
                        <td>:</td>
                        <td><input type="text" name="KelurahanTer" size="30"></td>
                    </tr>
                    <tr>
                        <td>Kecamatan</td>
                        <td>:</td>
                        <td><input type="text" name="KecamatanTer" size="30"></td>
                    </tr>
                    <tr>
                        <td>NO HP</td>
                        <td>:</td>
                        <td><input type="text" name="NoHpTer" size="15"></td>
                    </tr>
                    <tr>
                        <td>Pekerjaan</td>
                        <td>:</td>
                        <td><input type="text" name="PekerjaanTer" size="30"></td>
                    </tr>
                    <tr>
                        <td>Agama</td>
                        <td>:</td>
                        <td><input type="text" name="AgamaTer" size="10"></td>
                    </tr>
                    <tr>
                        <td>Hubungan Dengan Korban</td>
                        <td>:</td>
                        <td><input type="text" name="HubDenganKorbanTer" size="30"></td>
                    </tr>
                    <tr>
                        <td><input type="submit" name="proses" value="Simpan">
                            <input type="reset" value="Reset"></td>
                    </tr>
                </table>  
            </form>
        </div>
        </body>
        </html>
        <?php
    }
}

// Usage example
if(isset($_POST['proses'])){
    // Create an instance of FormData
    $formData = new FormData($_POST);

    // Assuming 'koneksi.php' file includes the database connection details
    include "koneksi.php";

    // Create an instance of Database
    $database = new Database($koneksi);

    // Insert data into the database
    $database->insertData($formData);
}

// Render the form
$form = new Form();
$form->render();

?>

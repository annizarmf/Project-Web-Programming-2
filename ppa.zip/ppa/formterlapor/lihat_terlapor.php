<?php

// Database class representing the database connection and data retrieval
class Database {
    private $connection;

    // Constructor to initialize database connection
    public function __construct($connection) {
        $this->connection = $connection;
    }

    // Method to fetch data from the database
    public function fetchData() {
        $terlapor = mysqli_query($this->connection, "SELECT * from dataterlapor");
        return $terlapor;
    }
}

// HTMLRenderer class responsible for rendering HTML content
class HTMLRenderer {
    // Method to render the HTML table
    public static function renderTable($terlapor) {
        echo "<a href=pelapor.php>Kembali</a>";
        echo "<br><h3>Data Pelapor</h3>";
        echo "<table border=1 class=styled-table>
        <tr>
            <td>No</td>
            <td>Nama</td>
            <td>NIK</td>
            <td>Tanggal Lahir</td>
            <td>Jenis Kelamin</td>
            <td>Alamat</td>
            <td>RT/RW</td>
            <td>Kelurahan</td>
            <td>Kecamatan</td>
            <td>Pekerjaan</td>
            <td>Agama</td>
            <td>Hubungan Dengan Korban</td>
        </tr>";

        $k = 1;
        while ($data = mysqli_fetch_assoc($terlapor)) {
            $class = $k % 2 == 1 ? 'ganjil' : 'genap';
            echo "<tr class=$class>
                <td>$k</td>
                <td>".$data['NamaTer']."</td>
                <td>".$data['NIKTer']."</td>
                <td>".$data['TglLahirTer']."</td>
                <td>".$data['JenisKelaminTer']."</td>
                <td>".$data['AlamatTer']."</td>
                <td>".$data['RTRWTer']."</td>
                <td>".$data['KelurahanTer']."</td>
                <td>".$data['KecamatanTer']."</td>
                <td>".$data['PekerjaanTer']."</td>
                <td>".$data['AgamaTer']."</td>
                <td>".$data['HubDenganKorbanTer']."</td>
            </tr>";
            $k++;
        }
        echo "</table>";
    }
}

// Usage example
include "koneksi.php";

// Create an instance of Database
$database = new Database($koneksi);

// Fetch data from the database
$terlapor = $database->fetchData();

// Render the HTML table
HTMLRenderer::renderTable($terlapor);

?>

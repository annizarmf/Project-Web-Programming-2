<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
</head>
<body>
    <h2>Login </h2>
    <form action="proses.php" method="post">
        <tr>
            <td><label for="username">Username:</label></td>
        <input type="text" name="username" required>
        <br>
        <td><label for="password">Password:</label></td>
        <input type="password" name="password" required>
        </tr>
        <button type="submit" name="login">Login</button>
    </form>
</body>
</html>

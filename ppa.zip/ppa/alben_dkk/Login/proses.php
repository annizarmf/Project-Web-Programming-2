<?php
session_start();
include "koneksi.php";

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Mencari pengguna berdasarkan username
    $query = "SELECT * FROM users WHERE username = ?";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    // Jika pengguna ditemukan
    if ($result && $user = mysqli_fetch_assoc($result)) {
        // Memeriksa kata sandi
        if (password_verify($password, $user['password'])) {
            // Menyimpan informasi pengguna dalam sesi
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = ($user['role'] === 'admin') ? 'admin' : 'user';

            // Mengarahkan ke dashboard sesuai peran
            $dashboardPage = ($_SESSION['role'] === 'admin') ? '../lib/top-page.php' : '../index.html';
            header("Location: $dashboardPage");
            exit();
        }
    }

    // Jika login gagal
     echo "Proses Login gagal . <a href='login.php'>Coba lagi yuk !!! </a>";
}
?>

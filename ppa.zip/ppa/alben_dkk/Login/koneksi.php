<?php

$host="localhost";
$user="root";
$pass="";
$db="laporan_kasus";

$koneksi = mysqli_connect($host, $user, $pass, $db);
?>
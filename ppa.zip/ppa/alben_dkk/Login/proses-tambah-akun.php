<?php
include "koneksi.php";

if (isset($_POST['tambah_akun'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    tambahAkun($koneksi, $username, $password, $role);

    // Pesan sukses atau pindahkan ke halaman lain jika diperlukan
    echo "Akun Anda Sudah Jadi!";
    // Untuk mengarahkan ke halaman lain, gunakan kode berikut:
    // header("Location: halaman_sukses.php");
    // exit();
}

mysqli_close($koneksi);

// Fungsi untuk menambahkan akun ke database
function tambahAkun($koneksi, $username, $password, $role) {
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $query = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, "sss", $username, $hashed_password, $role);

    mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);
}
?>

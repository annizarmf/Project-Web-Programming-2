<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Terlapor</title>
    <style>
        .styled-table {
    border-collapse: collapse;
    margin: 25px 0;
    font-size: 0.9em;
    font-family: sans-serif;
    min-width: 400px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }
    .styled-table thead tr {
    background-color: #009879;
    color: #ffffff;
    text-align: left;
    }
    .styled-table th,
    .styled-table td {
    padding: 12px 15px;
    }
    .styled-table tbody tr {
    border-bottom: 1px solid #dddddd;
    }
    .styled-table tbody tr:nth-of-type(even) {
    background-color: #f3f3f3;
    }
    .styled-table tbody tr:last-of-type {
    border-bottom: 2px solid #009879;
    }
    .styled-table tbody tr.active-row {
    font-weight: bold;
    color: #009879;
    }
    </style>

</head>
<body>
<div style="margin: 0 auto; width:40%; background: white;">
        
        <h3 align="center">DATA TERLAPOR</h3> 
        <form method="post">
        <table class="styled-table">
        <tr>
                    <td>Nama</td>
                    <td>:</td>
                    <td><input type="text" name="NamaTer" size="30"></td>
                </tr>
                <tr>
                    <td>NIK</td>
                    <td>:</td>
                    <td><input type="text" name="NIKTer" size="16"></td>
                </tr>
                <tr>
                    <td>Tanggal Lahir</td>
                    <td>:</td>
                    <td><input type="date" name="TglLahirTer"></td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td>:</td>
                    <td><input type="text" name="JenisKelaminTer" size="10"></td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td>:</td>
                    <td><textarea type="text" name="AlamatTer" size="100"></textarea></td>
                </tr>
                <tr>
                    <td>RT/RW</td>
                    <td>:</td>
                    <td><input type="text" name="RTRWTer" size="10"></td>
                </tr>
                <tr>
                    <td>Kelurahan</td>
                    <td>:</td>
                    <td><input type="text" name="KelurahanTer" size="30"></td>
                </tr>
                <tr>
                    <td>Kecamatan</td>
                    <td>:</td>
                    <td><input type="text" name="KecamatanTer" size="30"></td>
                </tr>
                <tr>
                    <td>NO HP</td>
                    <td>:</td>
                    <td><input type="text" name="NoHpTer" size="15"></td>
                </tr>
                <tr>
                    <td>Pekerjaan</td>
                    <td>:</td>
                    <td><input type="text" name="PekerjaanTer" size="30"></td>
                </tr>
                <tr>
                    <td>Agama</td>
                    <td>:</td>
                    <td><input type="text" name="AgamaTer" size="10"></td>
                </tr>
                <tr>
                    <td>Hubungan Dengan Korban</td>
                    <td>:</td>
                    <td><input type="text" name="HubDenganKorbanTer" size="30"></td>
                    </tr>
        </table>  
</Div>
<?php
    include "koneksi.php";
    if(isset($_POST['proses'])){
    mysqli_query($koneksi, "INSERT INTO dataterlapor SET
    NamaPel = '$_POST[NamaPel]',
    NIKPel = '$_POST[NIKPel]',
    TglLahirPel = '$_POST[TglLahirPel]',
    JenisKelaminPel = '$_POST[JenisKelaminPel]',
    AlamatPel = '$_POST[AlamatPel]',
    RTRWPel = '$_POST[RTRWPel]',
    KelurahanPel = '$_POST[KelurahanPel]',
    KecamatanPel = '$_POST[KecamatanPel]',
    NoHpPel = '$_POST[NoHpPel]',
    PekerjaanPel = '$_POST[PekerjaanPel]',
    AgamaPel = '$_POST[AgamaPel]',
    HubDenganKorban = '$_POST[HubDenganKorban]'
    ");
    echo "DATA TELAH TERSIMPAN";
}
?> 
</body>
</html>
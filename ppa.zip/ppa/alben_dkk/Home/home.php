<?php include "../lib/top-page.php"; ?>
<br><br><br><br><br><br> 
<center> Selamat Datang

<h3>Sistem Informasi UPTD KTPA (SIMPUG)</h3></center>
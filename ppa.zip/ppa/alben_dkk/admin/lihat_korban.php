<?php include "../lib/top-page.php"; ?>
<?php include "../lib/koneksi.php";?>
<head>
 	<style>
    table{
			border-collapse: collapse;
		}
  		.ganjil{
			background-color:#ECD0C4;
		}
  		.genap{
			background-color:#E5C4EC;
		}
  		.genap:hover, .ganjil:hover {
			background-color:lime;
		}
 </style>
</head>


<?php
 $korban = mysqli_query($koneksi, "SELECT * from datakorban");
 $jumlah_baris = mysqli_num_rows($korban);
 
 echo "<a href=korban.php>Kembali</a>";
 echo "<br><h3>Data Korban</h3>";
 echo "<table border=1>
		<tr>
		<td>No</td>
		 <td>Nama</td>
		 <td>NIK</td>
		 <td>Tanggal Lahir</td>
		 <td>Jenis Kelamin</td>
		 <td>Alamat</td>
		 <td>RT/RW</td>
		 <td>Kelurahan</td>
		 <td>Kecamatan</td>
		 <td>No Handphone</td>
		 <td>Pekerjaan</td>
		 <td>Agama</td>
		 <td>Hubungan Dengan Terlapor</td>
		</tr>" ;
 
 	for($k=1; $k<=$jumlah_baris; $k++)
 	{
	 $data = mysqli_fetch_assoc($korban);
	 if($k % 2 == 1)
	 {
	 echo "<tr class=ganjil>
			<td>$k</td>
			<td>".$data['NamaKor']."</td>
		    <td>".$data['NIKKor']."</td>
			<td>".$data['TglLahirKor']."</td>
			<td>".$data['JenisKelaminKor']."</td>
			<td>".$data['AlamatKor']."</td>
			<td>".$data['RTRWKor']."</td>
			<td>".$data['KelurahanKor']."</td>
			<td>".$data['KecamatanKor']."</td>
			<td>".$data['NoHpKor']."</td>
			<td>".$data['PekerjaanKor']."</td>
			<td>".$data['AgamaKor']."</td>
			<td>".$data['HubDenganTerlapor']."</td>
		   </tr>";
	   }
	   else
	   {
		echo "<tr class=genap>
		<td>$k</td>
		<td>".$data['NamaKor']."</td>
		<td>".$data['NIKKor']."</td>
		<td>".$data['TglLahirKor']."</td>
		<td>".$data['JenisKelaminKor']."</td>
		<td>".$data['AlamatKor']."</td>
		<td>".$data['RTRWKor']."</td>
		<td>".$data['KelurahanKor']."</td>
		<td>".$data['KecamatanKor']."</td>
		<td>".$data['NoHpKor']."</td>
		<td>".$data['PekerjaanKor']."</td>
		<td>".$data['AgamaKor']."</td>
		<td>".$data['HubDenganTerlapor']."</td>
	   </tr>";
	   }
	   
 	}	
	echo "</table>";

?>

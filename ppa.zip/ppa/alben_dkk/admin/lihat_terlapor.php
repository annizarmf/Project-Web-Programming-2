<?php include "../lib/top-page.php"; ?>
<?php include "../lib/koneksi.php";?>

<head>
 	<style>
    .styled-table {
    border-collapse: collapse;
    margin: 25px 0;
    font-size: 0.9em;
    font-family: sans-serif;
    min-width: 400px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }
    .styled-table thead tr {
    background-color: #009879;
    color: #ffffff;
    text-align: left;
    }
    .styled-table th,
    .styled-table td {
    padding: 12px 15px;
    }
    .styled-table tbody tr {
    border-bottom: 1px solid #dddddd;
    }
    .styled-table tbody tr:nth-of-type(even) {
    background-color: #f3f3f3;
    }
    .styled-table tbody tr:last-of-type {
    border-bottom: 2px solid #009879;
    }
    .styled-table tbody tr.active-row {
    font-weight: bold;
    color: #009879;
    }
 </style>
</head>

<?php
 $terlapor = mysqli_query($koneksi, "SELECT * from dataterlapor");
 $jumlah_baris = mysqli_num_rows($terlapor);
 
 //echo $jm_baris."<br>"; 
 echo "<a href=pelapor.php>Kembali</a>";
 echo "<br><h3>Data Pelapor</h3>";
 echo "<table border=1 class=styled-table>
		<tr>
		<td>No</td>
		 <td>Nama</td>
		 <td>NIK</td>
		 <td>Tanggal Lahir</td>
		 <td>Jenis Kelamin</td>
		 <td>Alamat</td>
		 <td>RT/RW</td>
		 <td>Kelurahan</td>
		 <td>Kecamatan</td>
		 <td>Pekerjaan</td>
		 <td>Agama</td>
		 <td>Hubungan Dengan Korban</td>
		</tr>" ;
 
 	for($k=1; $k<=$jumlah_baris; $k++)
 	{
	 $data = mysqli_fetch_assoc($terlapor);
	 if($k % 2 == 1)
	 {
	 echo "<tr class=ganjil>
			<td>$k</td>
			<td>".$data['NamaTer']."</td>
		    <td>".$data['NIKTer']."</td>
			<td>".$data['TglLahirTer']."</td>
			<td>".$data['JenisKelaminTer']."</td>
			<td>".$data['AlamatTer']."</td>
			<td>".$data['RTRWTer']."</td>
			<td>".$data['KelurahanTer']."</td>
			<td>".$data['KecamatanTer']."</td>
			<td>".$data['PekerjaanTer']."</td>
			<td>".$data['AgamaTer']."</td>
			<td>".$data['HubDenganKorbanTer']."</td>
		   </tr>";
	   }
	   else
	   {
		    echo "<tr class=genap>
			<td>$k</td>
			<td>".$data['NamaTer']."</td>
		    <td>".$data['NIKTer']."</td>
			<td>".$data['TglLahirTer']."</td>
			<td>".$data['JenisKelaminTer']."</td>
			<td>".$data['AlamatTer']."</td>
			<td>".$data['RTRWTer']."</td>
			<td>".$data['KelurahanTer']."</td>
			<td>".$data['KecamatanTer']."</td>
			<td>".$data['PekerjaanTer']."</td>
			<td>".$data['AgamaTer']."</td>
			<td>".$data['HubDenganKorbanTer']."</td>
		   </tr>";
	   }
 	}	
	 echo "</table>";

?>

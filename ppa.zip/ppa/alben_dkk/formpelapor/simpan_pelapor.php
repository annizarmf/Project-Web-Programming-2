<?php
	$NamaPel = $_POST['NamaPel'];
	$NIKPel = $_POST['NIKPel'];
	$TglLahirPel = $_POST['TglLahirPel'];
	$JenisKelaminPel = $_POST['JenisKelaminPel'];
	$AlamatPel = $_POST['AlamatPel'];
	$RTRWPel = $_POST['RTRWPel'];
	$KeluharanPel = $_POST['KelurahanPel'];
	$KecamatanPel = $_POST['KecamatanPel'];
	$PekerjaanPel = $_POST['PekerjaanPel'];
	$AgamaPel = $_POST['AgamaPel'];
	$HubDenganKorban = $_POST['HubDenganKorban'];
	
	include "koneksi.php";
	
	//validasi redundant data atau data yang sama
	
	$cek = mysqli_query($koneksi, "SELECT * from datapelapor where NIKPel ='$NIKPel'");
	$jumlah = mysqli_num_rows($cek);
	//echo $jumlah;
	
	if($jumlah == 1)
	{
		echo "
		 <script>
		  alert('Data sudah ada');
		  window.location = 'datapelapor.php?NIKPel=$NIKPel';
		 </script>
		";
	}
	else
	{
		$simpan = mysqli_query($koneksi,"INSERT into datapelapor set 
		NamaPel ='$NamaPel',
		NIKPel ='$NIKPel',
		TglLahirPel ='$TglLahirPel',
		JenisKelaminPel ='$JenisKelaminPel',
		AlamatPel ='$AlamatPel',
		RTRWPel ='$RTRWPel',
		kelurahanPel ='$kelurahanPel',
		KecamatanPel ='$KecamatanPel',
		PekerjaanPel ='$PekerjaanPel',
		HubDenganKorban ='$HubDenganKorban'");
		
		if($simpan)
		{
			echo "
			 <script>
			  alert('Data berhasil ditambahkan');
			  window.location = 'pelapor.php';
			 </script>
		";
		}
	}
	//

?>

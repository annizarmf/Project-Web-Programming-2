<?php
	$JenisKasus = $_POST['JenisKasus'];
	$SubKasus = $_POST['SubKasus'];
	$Keterangan = $_POST['Keterangan'];
	$Kronologis = $_POST['JenisKelaminPel'];
	$AlamatPel = $_POST['Kronologis'];
	$KondisiKorban = $_POST['KondisiKorban'];
	$Upaya = $_POST['Upaya'];
	$KebutuhanKroban = $_POST['KebutuhanKorban'];

	
	include "koneksi.php";
	
	//validasi redundant data atau data yang sama
	
	$cek = mysqli_query($koneksi, "SELECT * from data_kasus where NIKPel ='$SubKasus'");
	$jumlah = mysqli_num_rows($cek);
	//echo $jumlah;
	
	if($jumlah == 1)
	{
		echo "mysqli_query($koneksi,"INSERT into datakasus set 
		JenisKasus ='$JenisKasus',
		SubKasus ='$SubKasus',
		Keterangan ='$Keterangan',
		Kronologis ='$Kronologis',
		KondisiKorban ='$KondisiKorban',
		Upaya ='$Upaya',
		KebutuhanKorban ='$KebutuhanKorban'");
		
		
		if($simpan)
		{
			echo "
			 <script>
			  alert('Data berhasil ditambahkan');
			  window.location = 'data_kasus.php';
			 </script>
		";
		}
	}
	//

?>

		 <script>
		  alert('Data sudah ada');
		  window.location = 'data_kasus.php?SubKasus=$SubKasus';
		 </script>
		";
	}
	else
	{
		$simpan = 
<style>
    .styled-table {
    border-collapse: collapse;
    margin: 25px 0;
    font-size: 0.9em;
    font-family: sans-serif;
    min-width: 400px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }
    .styled-table thead tr {
    background-color: #009879;
    color: #ffffff;
    text-align: left;
    }
    .styled-table th,
    .styled-table td {
    padding: 12px 15px;
    }
    .styled-table tbody tr {
    border-bottom: 1px solid #dddddd;
    }
    .styled-table tbody tr:nth-of-type(even) {
    background-color: #f3f3f3;
    }
    .styled-table tbody tr:last-of-type {
    border-bottom: 2px solid #009879;
    }
    .styled-table tbody tr.active-row {
    font-weight: bold;
    color: #009879;
    }
</style>

<?php
                 $JenisKasus = '$_GET[JenisKasus]',
                 $SubKasus = '$_GET[SubKasus]',
                 $Keterangan = '$_GET[Keterangan]',
                 $Kronologis = '$_GET[Kronologis]',
                 $KondisiKorban = '$_GET[KondisiKorban]',
                 $Upaya = '$_GET[Upaya]',
                 $KebutuhanKorban = '$_GET[KebutuhanKorban]',
                 

echo "
<h3 align="center">DATA KASUS</h3> 
<form method="post">
<table class="styled-table">
<tr>
                <td width="130">Jenis Kasus</td>
                <td>:</td>
                <td><select name="$JenisKasus">
                    <option value="">-- Pilih -- </option>
                    <option value="KDRT"> KDRT (Kekerasan Dalam Rumah Tangga)</option>
                    <option value="KBGO"> KBGO (Kekerasan Berbasis Gender Online)</option>
                    <option value="KTP">KTP (Kekerasan Terhadap Perempuan)</option>
                    <option value="TPPO">KDP (Kekerasan Dalam Pacaran)</option>
                    <option value="TPPO">TPPO (Tindak Pidana Perdagangan Orang)</option>
                    <option value="ODGJ">ODGJ (Orang Dengan Gangguan Jiwa)</option>
                    <option value="KTA/ABK">KTA/ABK (Anak Berkebutuhan Khusus)</option>
                </select></td>
            </tr>
            <tr>
                <td>Sub Kasus </td>
                <td>:</td>
                <td><select name="$SubKasus">
                    <option value="">-- Pilih -- </option>
                    <option value="Bullying">Bullying</option>
                    <option value="Pelecehan">Pelecehan </option>
                    <option value="Pencabulan"> Persetubuhan</option>
                    <option value="penelantaran"> Penelantaran </option>
                    <option value="Pencabulan"> Pencabulan</option>
                    <option value="Pemerkosaan">Pemerkosaan</option>
                    <option value="Kekerasan Fisik">Kekerasan Fisik </option>
                    <option value="Kekerasan Psikis">Kekerasan Psikis</option>
                </select></td>
            </tr>
            <tr>
                <td valign="top">Keterangan</td>
                <td>:</td>
                <td><textarea name="Keterangan" name=NamaPel size=30 value=$Keterangan></td>
            </tr>
            <tr>
                <td valign="top">Kronologis</td>
                <td>:</td>
                <td><textarea name="Kronologi" name=NamaPel size=30 value=$Kronologis></td>
                </tr>
            </tr>
            <tr>
                <td valign="top">Kondisi dan Kebutuhan</td>
                <td>:</td>
                <td><textarea name="KondisiKorban" name=NamaPel size=30 value=$KondisiKorban></td>
                </tr>
            </tr>
            <tr>
                <td valign="top">Upaya yang Telah Dilakukan</td>
                <td>:</td>
                <td><textarea name="Upaya" name=NamaPel size=30 value=$Upaya></td>
                </tr>
            </tr>
            <tr>
                <td>Kebutuhan Korban </td>
                <td>:</td>
                <td><select name="$KebutuhanKorban">
                    <option value="">-- Pilih -- </option>
                    <option value="Pendampingan_Hukum">Pendampingan Hukum</option>
                    <option value="Pendampingan_Psikolog">Pendampingan Psikolog</option>
                    <option value="Mediasi">Mediasi</option>
                    <option value="Rumah_Aman">Rumah Aman</option>
                </select></td>
            </tr>
            <tr>
                <td><input type="submit" name="proses" value="Simpan">
                <input type="reset" value="Reset"></td>
            </tr>
        </table>
    </form>
";
?>
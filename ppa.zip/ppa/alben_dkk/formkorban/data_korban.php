<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        
    .styled-table {
    border-collapse: collapse;
    margin: 25px 0;
    font-size: 0.9em;
    font-family: sans-serif;
    min-width: 400px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }
    .styled-table thead tr {
    background-color: #009879;
    color: #ffffff;
    text-align: left;
    }
    .styled-table th,
    .styled-table td {
    padding: 12px 15px;
    }
    .styled-table tbody tr {
    border-bottom: 1px solid #dddddd;
    }
    .styled-table tbody tr:nth-of-type(even) {
    background-color: #f3f3f3;
    }
    .styled-table tbody tr:last-of-type {
    border-bottom: 2px solid #009879;
    }
    .styled-table tbody tr.active-row {
    font-weight: bold;
    color: #009879;
    }
    </style>
</head>
<body>

<div style="margin: 0 auto; width:40%; background: white;">
        
    <h3 align="center">DATA KORBAN</h3>
    <form method="post">
    <table class="styled-table">
            <tr>
                <td>Nama</td>
                <td>:</td>
                <td><input type="text" name="NamaKor" size="30"></td>
            </tr>
            <tr>
                <td>NIK</td>
                <td>:</td>
                <td><input type="text" name="NIKKor" size="16"></td>
            </tr>
            <tr>
                <td>Tanggal Lahir</td>
                <td>:</td>
                <td><input type="date" name="TglLahirKor"></td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td>:</td>
                <td><input type="text" name="JenisKelaminKor" size="10"></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>:</td>
                <td><textarea name="AlamatKor" rows="3" cols="40"></textarea></td>
            </tr>
            <tr>
                <td>RT/RW</td>
                <td>:</td>
                <td><input type="text" name="RTRWKor" size="10"></td>
            </tr>
            <tr>
                <td>Kelurahan</td>
                <td>:</td>
                <td><input type="text" name="KelurahanKor" size="30"></td>
            </tr>
            <tr>
                <td>Kecamatan</td>
                <td>:</td>
                <td><input type="text" name="KecamatanKor" size="30"></td>
            </tr>
            <tr>
                <td>NO HP</td>
                <td>:</td>
                <td><input type="text" name="NoHpKor" size="15"></td>
            </tr>
            <tr>
                <td>Pekerjaan</td>
                <td>:</td>
                <td><input type="text" name="PekerjaanKor" size="30"></td>
            </tr>
            <tr>
                <td>Agama</td>
                <td>:</td>
                <td><input type="text" name="AgamaKor" size="10"></td>
            </tr>
            <tr>
                <td>Hubungan Dengan Terlapor</td>
                <td>:</td>
                <td><textarea name="HubDenganTerlapor" rows="3" cols="40"></textarea></td>
            </tr>
                <tr>
                    <td><input type="submit" name="proses" value="Simpan">
                    <input type="reset" value="Reset"></td>
                </tr>
    </table>
</form>
    </div>
    
                <?php
                include "koneksi.php";
                if(isset($_POST['proses'])){
                 mysqli_query($koneksi, "INSERT INTO datakorban SET
                 NamaKor = '$_POST[NamaKor]',
                 NIKKor = '$_POST[NIKKor]',
                 TglLahirKor = '$_POST[TglLahirKor]',
                 JenisKelaminKor = '$_POST[JenisKelaminKor]',
                 AlamatKor = '$_POST[AlamatKor]',
                 RTRWKor = '$_POST[RTRWKor]',
                 KelurahanKor = '$_POST[KelurahanKor]',
                 KecamatanKor = '$_POST[KecamatanKor]',
                 NoHpKor = '$_POST[NoHpKor]',
                 PekerjaanKor = '$_POST[PekerjaanKor]',
                 AgamaKor = '$_POST[AgamaKor]',
                 HubDenganTerlapor = '$_POST[HubDenganTerlapor]'
                 ");

echo "DATA TELAH TERSIMPAN";
                }
                ?> 
</body>
</html>